package com.lutcam

import java.io.InputStream

/** .cube 3D LUT parser. Data order: red fastest, then green, then blue. */
class CubeLut(val size: Int, val rgb: FloatArray) {
    /** [R][G][B] ARGB ints for Media3 SingleColorLut */
    fun toCube(): Array<Array<IntArray>> = Array(size) { r -> Array(size) { g -> IntArray(size) { b ->
        val i = ((b * size + g) * size + r) * 3
        val rr = (rgb[i].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        val gg = (rgb[i + 1].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        val bb = (rgb[i + 2].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
        (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
    } } }

    companion object {
        fun parse(s: InputStream): CubeLut {
            var n = 0; var buf = FloatArray(0); var k = 0
            s.bufferedReader().useLines { lines ->
                for (raw in lines) {
                    val l = raw.trim()
                    if (l.isEmpty() || l.startsWith("#")) continue
                    val p = l.split(Regex("\\s+"))
                    when {
                        p[0] == "LUT_3D_SIZE" -> { n = p[1].toInt(); buf = FloatArray(n * n * n * 3) }
                        p[0] == "LUT_1D_SIZE" -> throw IllegalArgumentException("1D LUT supported chhaina")
                        p[0][0].isLetter() -> {}
                        p.size >= 3 && k + 3 <= buf.size -> { for (j in 0..2) buf[k++] = p[j].toFloat() }
                    }
                }
            }
            require(n > 1 && k == buf.size) { "Invalid .cube file" }
            return CubeLut(n, buf)
        }
    }
}
