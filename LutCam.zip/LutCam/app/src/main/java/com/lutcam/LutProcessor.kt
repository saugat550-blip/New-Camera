package com.lutcam

import android.graphics.SurfaceTexture
import android.opengl.*
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceProcessor
import androidx.camera.core.SurfaceRequest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.Executor

/** Live GPU LUT: preview ra recorded video duitai ma LUT bake garchha. */
class LutProcessor : SurfaceProcessor {
    private val thread = HandlerThread("lut-gl").apply { start() }
    private val handler = Handler(thread.looper)
    val executor = Executor { handler.post(it) }

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var cfg: EGLConfig? = null
    private var dummy: EGLSurface = EGL14.EGL_NO_SURFACE
    private var prog = 0; private var oes = 0; private var lutTex = 0
    private var uTex = 0; private var uOn = 0; private var uSize = 0
    private var input: SurfaceTexture? = null
    private val outs = HashMap<SurfaceOutput, EGLSurface>()
    private val inM = FloatArray(16); private val outM = FloatArray(16)
    @Volatile private var pending: CubeLut? = null
    @Volatile private var lutSize = 0
    @Volatile private var released = false

    private val pos: FloatBuffer = fb(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val tex: FloatBuffer = fb(floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f))
    private fun fb(a: FloatArray) = ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder())
        .asFloatBuffer().apply { put(a); position(0) }

    init { handler.post { initGl() } }

    fun setLut(l: CubeLut?) { pending = l; if (l == null) lutSize = 0 }

    private fun initGl() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2); EGL14.eglInitialize(dpy, v, 0, v, 1)
        val attr = intArrayOf(EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT or EGL14.EGL_PBUFFER_BIT,
            EGLExt.EGL_RECORDABLE_ANDROID, 1, EGL14.EGL_NONE)
        val c = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attr, 0, c, 0, 1, n, 0); cfg = c[0]
        ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        dummy = EGL14.eglCreatePbufferSurface(dpy, cfg,
            intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, dummy, dummy, ctx)

        val t = IntArray(2); GLES30.glGenTextures(1, t, 0); oes = t[0]
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oes)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        prog = link(VS, FS)
        uTex = GLES30.glGetUniformLocation(prog, "uTex")
        uOn = GLES30.glGetUniformLocation(prog, "uOn")
        uSize = GLES30.glGetUniformLocation(prog, "uSize")
        GLES30.glUseProgram(prog)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(prog, "sCam"), 0)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(prog, "sLut"), 1)
    }

    private fun link(vs: String, fs: String): Int {
        fun sh(type: Int, src: String) = GLES30.glCreateShader(type).also {
            GLES30.glShaderSource(it, src); GLES30.glCompileShader(it)
            val ok = IntArray(1); GLES30.glGetShaderiv(it, GLES30.GL_COMPILE_STATUS, ok, 0)
            check(ok[0] != 0) { GLES30.glGetShaderInfoLog(it) }
        }
        return GLES30.glCreateProgram().also {
            GLES30.glAttachShader(it, sh(GLES30.GL_VERTEX_SHADER, vs))
            GLES30.glAttachShader(it, sh(GLES30.GL_FRAGMENT_SHADER, fs))
            GLES30.glLinkProgram(it)
        }
    }

    private fun uploadLut(l: CubeLut) {
        if (lutTex == 0) { val t = IntArray(1); GLES30.glGenTextures(1, t, 0); lutTex = t[0] }
        GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, lutTex)
        val b = ByteBuffer.allocateDirect(l.rgb.size * 4).order(ByteOrder.nativeOrder())
        b.asFloatBuffer().put(l.rgb); b.position(0)
        GLES30.glTexImage3D(GLES30.GL_TEXTURE_3D, 0, GLES30.GL_RGB16F, l.size, l.size, l.size, 0,
            GLES30.GL_RGB, GLES30.GL_FLOAT, b)
        for (p in intArrayOf(GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_TEXTURE_MAG_FILTER))
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, p, GLES30.GL_LINEAR)
        for (p in intArrayOf(GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_TEXTURE_WRAP_R))
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_3D, p, GLES30.GL_CLAMP_TO_EDGE)
        lutSize = l.size
    }

    override fun onInputSurface(request: SurfaceRequest) {
        handler.post {
            if (released) { request.willNotProvideSurface(); return@post }
            val st = SurfaceTexture(oes)
            st.setDefaultBufferSize(request.resolution.width, request.resolution.height)
            val s = Surface(st)
            input = st
            st.setOnFrameAvailableListener({ draw() }, handler)
            request.provideSurface(s, executor) {
                st.setOnFrameAvailableListener(null); st.release(); s.release()
                if (input === st) input = null
            }
        }
    }

    override fun onOutputSurface(out: SurfaceOutput) {
        handler.post {
            if (released) { out.close(); return@post }
            val s = out.getSurface(executor) {
                handler.post {
                    outs.remove(out)?.let { e -> EGL14.eglMakeCurrent(dpy, dummy, dummy, ctx); EGL14.eglDestroySurface(dpy, e) }
                    out.close()
                }
            }
            outs[out] = EGL14.eglCreateWindowSurface(dpy, cfg, s, intArrayOf(EGL14.EGL_NONE), 0)
        }
    }

    private fun draw() {
        val st = input ?: return
        if (released) return
        EGL14.eglMakeCurrent(dpy, dummy, dummy, ctx)
        st.updateTexImage(); st.getTransformMatrix(inM)
        val ts = st.timestamp
        pending?.let { uploadLut(it); pending = null }
        for ((o, e) in outs) {
            EGL14.eglMakeCurrent(dpy, e, e, ctx)
            GLES30.glViewport(0, 0, o.size.width, o.size.height)
            o.updateTransformMatrix(outM, inM)
            GLES30.glUseProgram(prog)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oes)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_3D, lutTex)
            GLES30.glUniformMatrix4fv(uTex, 1, false, outM, 0)
            GLES30.glUniform1f(uOn, if (lutSize > 0) 1f else 0f)
            GLES30.glUniform1f(uSize, lutSize.toFloat())
            GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, pos)
            GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 0, tex)
            GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
            EGLExt.eglPresentationTimeANDROID(dpy, e, ts)
            EGL14.eglSwapBuffers(dpy, e)
        }
    }

    fun release() {
        handler.post {
            released = true
            outs.values.forEach { EGL14.eglDestroySurface(dpy, it) }; outs.clear()
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroyContext(dpy, ctx); EGL14.eglTerminate(dpy)
            thread.quitSafely()
        }
    }

    companion object {
        private const val VS = """#version 300 es
layout(location=0) in vec2 aPos; layout(location=1) in vec2 aTex;
uniform mat4 uTex; out vec2 vTex;
void main(){ gl_Position=vec4(aPos,0.,1.); vTex=(uTex*vec4(aTex,0.,1.)).xy; }"""
        private const val FS = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision highp float;
uniform samplerExternalOES sCam; uniform highp sampler3D sLut;
uniform float uOn; uniform float uSize; in vec2 vTex; out vec4 o;
void main(){
  vec3 c=texture(sCam,vTex).rgb;
  if(uOn>0.5){ vec3 q=clamp(c,0.,1.)*((uSize-1.)/uSize)+0.5/uSize; c=texture(sLut,q).rgb; }
  o=vec4(c,1.);
}"""
    }
}
