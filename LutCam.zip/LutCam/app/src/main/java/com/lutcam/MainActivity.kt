package com.lutcam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.util.Range
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.SingleColorLut
import androidx.media3.transformer.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@UnstableApi
class MainActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var recBtn: Button
    private var provider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private val processor by lazy { LutProcessor() }
    private var lut: CubeLut? = null
    private var live = false

    private val pickLut = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        u ?: return@registerForActivityResult
        runCatching { contentResolver.openInputStream(u)!!.use { CubeLut.parse(it) } }
            .onSuccess { lut = it; say("LUT load bhayo (${it.size}³)"); bind() }
            .onFailure { say("LUT error: ${it.message}") }
    }
    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        u?.let { export(it) }
    }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (it.values.all { g -> g }) bind() else say("Camera/Mic permission chahincha")
    }

    private fun say(s: String) = runOnUiThread { status.text = s }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        previewView = PreviewView(this).apply { implementationMode = PreviewView.ImplementationMode.COMPATIBLE }
        status = TextView(this).apply { setTextColor(-1); setPadding(16, 8, 16, 8); text = "4K 60fps • stabilized" }
        recBtn = btn("● REC") { toggleRec() }
        val sw = Switch(this).apply {
            text = "Live LUT "; setTextColor(-1)
            setOnCheckedChangeListener { _, c -> live = c; bind() }
        }
        val row = LinearLayout(this).apply {
            setBackgroundColor(0xAA000000.toInt()); gravity = Gravity.CENTER_VERTICAL
            addView(btn("LUT") { pickLut.launch(arrayOf("*/*")) })
            addView(sw); addView(recBtn)
            addView(btn("Export+LUT") {
                if (lut == null) say("Pahila LUT choose gara") else pickVideo.launch(arrayOf("video/*"))
            })
        }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(0xFF000000.toInt()); fitsSystemWindows = true
            addView(previewView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            addView(status, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP))
            addView(row, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        })
        val need = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (need.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) bind()
        else perms.launch(need)
    }

    private fun bind() {
        if (recording != null) { say("Recording ru'da bind garna milena"); return }
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val p = f.get().also { provider = it }
            p.unbindAll()
            val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
            val recorder = Recorder.Builder().setQualitySelector(
                QualitySelector.from(Quality.UHD, FallbackStrategy.lowerQualityThan(Quality.UHD))).build()
            val vc = VideoCapture.Builder(recorder)
                .setTargetFrameRate(Range(60, 60))
                .setVideoStabilizationEnabled(true)
                .build().also { videoCapture = it }
            val g = UseCaseGroup.Builder().addUseCase(preview).addUseCase(vc)
            if (live && lut != null) {
                processor.setLut(lut)
                g.addEffect(CameraEffect.Builder(CameraEffect.PREVIEW or CameraEffect.VIDEO_CAPTURE)
                    .setSurfaceProcessor(processor.executor, processor) { Log.e("LutCam", "effect", it) }.build())
            }
            try {
                p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, g.build())
                say(if (live && lut != null) "4K60 • stabilized • LIVE LUT" else "4K60 • stabilized")
            } catch (e: Exception) { say("Camera bind error: ${e.message}") }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleRec() {
        recording?.let { it.stop(); recording = null; recBtn.text = "● REC"; return }
        val vc = videoCapture ?: return
        val name = "LUTCam_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/LutCam")
        }
        val o = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        recording = vc.output.prepareRecording(this, o).withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { ev ->
                if (ev is VideoRecordEvent.Finalize) {
                    recording = null; recBtn.text = "● REC"
                    say(if (ev.hasError()) "Record error ${ev.error}" else "Save bhayo: Movies/LutCam")
                }
            }
        recBtn.text = "■ STOP"
    }

    private fun export(src: Uri) {
        val l = lut ?: return
        say("Export suru...")
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(src))
            .setEffects(Effects(listOf(), listOf(SingleColorLut.createFromCube(l.toCube())))).build()
        val out = File(cacheDir, "exp_${System.currentTimeMillis()}.mp4")
        val t = Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H265)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, r: ExportResult) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, "LUT_" + out.name)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/LutCam")
                    }
                    val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(u)!!.use { o -> out.inputStream().use { it.copyTo(o) } }
                    out.delete(); say("Export done: Movies/LutCam")
                }
                override fun onError(c: Composition, r: ExportResult, e: ExportException) = say("Export error: ${e.message}")
            }).build()
        t.start(edited, out.absolutePath)
    }

    override fun onDestroy() { super.onDestroy(); processor.release() }
}
